These are the services referenced in this video:

https://us-east-1.console.aws.amazon.com/directconnect/v2/home?region=us-east-2#/

https://s3.console.aws.amazon.com/s3/get-started?region=us-east-2

https://docs.aws.amazon.com/managedservices/latest/userguide/cloud-endure.html

https://aws.amazon.com/blogs/apn/design-considerations-for-disaster-recovery-with-vmware-cloud-on-aws/

https://us-east-2.console.aws.amazon.com/outposts/home?region=us-east-2#Home
