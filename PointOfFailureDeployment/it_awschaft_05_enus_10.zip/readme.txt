aws servicediscovery discover-instances \
--namespace-name myServiceNamespace \
--service-name myBackendService \
--health-status ALL